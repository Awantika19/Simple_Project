// var audio = document.createElement('audio');
// audio.setAttribute('Audio/sound.mp3'); 
// audio.loop=true;
// audio.play();

var audioElement=new Audio();
audioElement.src="Audio/sound.mp3";
audioElement.play();